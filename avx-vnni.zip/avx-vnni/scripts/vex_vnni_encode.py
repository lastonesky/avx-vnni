#!/usr/bin/env python3
"""Encode AVX-VNNI instructions as VEX machine code bytes.

Why this exists:
    MSVC's `_mm256_dpbusd_epi32` and MASM64's `vpdpbusd` both emit the **EVEX**
    (AVX512-VNNI) encoding, which faults with #UD on AVX-VNNI-only CPUs
    (Alder Lake / Arrow Lake / Zen4). MASM64 additionally rejects `{vex3}`.
    The only reliable way to get a VEX-encoded vpdpbusd in .asm is to emit raw
    bytes -- so this script computes them.

Verified by compiling with MSVC 14.51 (/arch:AVX2) and disassembling with dumpbin:
    vpdpbusd ymm0, ymm4, [rdx]        -> C4 E2 5D 50 02     (used in assets/vnni_asm.asm)
    vpdpbusd ymm1, ymm5, [rdx+0x20]   -> C4 E2 55 50 4A 20
    vpdpbusd ymm2, ymm4, [rdx+0x40]   -> C4 E2 5D 50 52 40
    vpdpbusd ymm3, ymm5, [rdx+0x60]   -> C4 E2 55 50 5A 60
    vpdpbusd ymm0, ymm1, [r8]         -> C4 C2 75 50 00
    vpdpbssd ymm0, ymm1, [r8]         -> C4 C2 77 50 00
    vpdpbsud ymm0, ymm1, [r8]         -> C4 C2 76 50 00
    vpdpbuud ymm0, ymm1, [r8]         -> C4 C2 74 50 00
    vpdpwssd ymm0, ymm1, [r8]         -> C4 C2 75 52 00

Usage:
    python vex_vnni_encode.py vpdpbusd  --dst ymm0 --src1 ymm4 --base rdx
    python vex_vnni_encode.py vpdpbusds --dst ymm1 --src1 ymm5 --base rdx --disp 0x20
    python vex_vnni_encode.py vpdpbusd  --dst ymm0 --src1 ymm4 --base rdx --all-dst
    python vex_vnni_encode.py custom    --opcode 0x52 --w 1 --dst ymm0 --src1 ymm4 --base rdx
"""

import argparse
import sys

# opcode 0F38, W field, VEX pp field (implied legacy prefix), hardware-verified.
#
# All byte-product VNNI ops live in the 0F38 map at opcode 50/51 and are told
# apart ONLY by the VEX pp field:
#     pp=00 (none) -> u8 x u8      pp=01 (66) -> u8 x s8
#     pp=10 (F3)   -> s8 x u8      pp=11 (F2) -> s8 x s8
# opcode 50 = wrap, 51 = signed-saturating. 52/53 = the i16 (word) forms.
#
# Every row below was confirmed by compiling with MSVC 14.51 (/arch:AVX2) and
# disassembling with dumpbin, e.g. `_mm256_dpbssd_epi32` -> C4 C2 77 50 00.
KNOWN = {
    "vpdpbuud":  (0x50, 0, 0b00),
    "vpdpbuuds": (0x51, 0, 0b00),
    "vpdpbusd":  (0x50, 0, 0b01),
    "vpdpbusds": (0x51, 0, 0b01),
    "vpdpbsud":  (0x50, 0, 0b10),
    "vpdpbsuds": (0x51, 0, 0b10),
    "vpdpbssd":  (0x50, 0, 0b11),
    "vpdpbssds": (0x51, 0, 0b11),
    # AVX-VNNI_INT16 (vpdpwssd) -- VEX encoding confirmed, but the CPU needs
    # CPUID.7.1:EAX[10]; check that before using these.
    "vpdpwssd":  (0x52, 0, 0b01),
    "vpdpwssds": (0x53, 0, 0b01),
}

GPR64 = {
    "rax": 0, "rcx": 1, "rdx": 2, "rbx": 3, "rsp": 4, "rbp": 5, "rsi": 6, "rdi": 7,
    "r8": 8, "r9": 9, "r10": 10, "r11": 11, "r12": 12, "r13": 13, "r14": 14, "r15": 15,
}


def parse_vec(name):
    n = name.lower()
    for p in ("ymm", "xmm", "zmm"):
        if n.startswith(p):
            try:
                v = int(n[len(p):])
            except ValueError:
                break
            if 0 <= v <= 15:
                return v
    raise ValueError("bad vector register: %r (expect ymm0..ymm15)" % name)


def encode(opcode, w, pp, dst, src1, base, disp, width256=True):
    """Return the bytes for VEX.256.0F38.W<w> pp<pp> <opcode> /r, memory operand."""
    if base not in GPR64:
        raise ValueError("bad base register: %r" % base)
    rm = GPR64[base]

    if disp == 0 and (rm & 7) == 4:          # rsp / r12 need a SIB byte
        raise ValueError("rsp/r12 as base requires SIB; not supported")
    if disp == 0 and (rm & 7) == 5:          # rbp / r13 with mod=00 means RIP-relative
        raise ValueError("rbp/r13 requires disp=1 (mod=01); use --disp 0")

    mod = 0x00 if disp == 0 else 0x01
    if mod == 0x01 and not (-128 <= disp <= 127):
        raise ValueError("disp %d does not fit in disp8" % disp)

    # VEX byte 2: [7]~R [6]~X [5]~B [4:0] mmmmm   (mmmmm = 00010 -> 0F38 map)
    r_ext = (dst >> 3) & 1
    b_ext = (rm >> 3) & 1
    byte2 = ((~r_ext & 1) << 7) | (1 << 6) | ((~b_ext & 1) << 5) | 0b00010

    # VEX byte 3: [7]W [6:3]~vvvv [2]L [1:0]pp
    l_bit = 1 if width256 else 0
    byte3 = ((w & 1) << 7) | ((~src1 & 0xF) << 3) | (l_bit << 2) | (pp & 0b11)

    modrm = (mod << 6) | ((dst & 7) << 3) | (rm & 7)

    out = [0xC4, byte2, byte3, opcode, modrm]
    if mod == 0x01:
        out.append(disp & 0xFF)
    return out


def fmt(bytes_, note=""):
    hexs = " ".join("%02X" % b for b in bytes_)
    masm = ", ".join("0%02Xh" % b for b in bytes_)
    nasm = ", ".join("0x%02X" % b for b in bytes_)
    return (hexs, "    db  %-40s ; %s" % (masm + ",", note), "    db  %s" % nasm)


def main():
    ap = argparse.ArgumentParser(description="Encode VEX.256 AVX-VNNI instructions.")
    ap.add_argument("op", help="vpdpbusd | vpdpbusds | vpdpwssd | vpdpwssds | custom")
    ap.add_argument("--dst", default="ymm0", help="destination register (also modrm.reg)")
    ap.add_argument("--src1", default="ymm4", help="vvvv source register (must be a register)")
    ap.add_argument("--base", default="rdx", help="memory base register")
    ap.add_argument("--disp", default="0", help="displacement, e.g. 32 or 0x20")
    ap.add_argument("--opcode", help="raw opcode byte (hex) when op=custom")
    ap.add_argument("--w", type=int, default=0, help="VEX W bit when op=custom")
    ap.add_argument("--pp", type=lambda s: int(s, 0), default=0,
                    help="VEX pp field 0..3 when op=custom (0=none 1=66 2=F3 3=F2)")
    ap.add_argument("--xmm", action="store_true", help="128-bit (L=0) instead of 256-bit")
    ap.add_argument("--all-dst", action="store_true",
                    help="emit all 8 destinations ymm0..ymm7 with the same src1/base")
    a = ap.parse_args()

    if a.op == "custom":
        if a.opcode is None:
            ap.error("custom requires --opcode")
        opcode, w, pp = int(a.opcode, 0), a.w, a.pp
    elif a.op in KNOWN:
        opcode, w, pp = KNOWN[a.op]
    else:
        ap.error("unknown op %r (known: %s, custom)" % (a.op, ", ".join(sorted(KNOWN))))

    disp = int(a.disp, 0)
    dst0 = parse_vec(a.dst)
    src1 = parse_vec(a.src1)

    dsts = range(0, 8) if a.all_dst else [dst0]
    for dst in dsts:
        try:
            b = encode(opcode, w, pp, dst, src1, a.base, disp, width256=not a.xmm)
        except ValueError as e:
            print("error: %s" % e, file=sys.stderr)
            return 1
        d = "[%s]" % a.base if disp == 0 else "[%s+0x%02X]" % (a.base, disp & 0xFF)
        note = "%s ymm%d, ymm%d, %s" % (a.op, dst, src1, d)
        hexs, masm, nasm = fmt(b, note)
        print("%-30s %s" % (note + ":", hexs))
        print(masm)
        print(nasm)
        print()

    if a.op in ("vpdpwssd", "vpdpwssds"):
        print("NOTE: %s needs AVX-VNNI_INT16 (CPUID.7.1:EAX[10]); detect before use."
              % a.op, file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
