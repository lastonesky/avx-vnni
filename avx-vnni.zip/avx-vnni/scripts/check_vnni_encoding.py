#!/usr/bin/env python3
"""Check whether VNNI instructions in a COFF object / PE binary are VEX or EVEX.

Why this exists:
    MSVC and ml64 both default to the **EVEX** (AVX512-VNNI) encoding for
    `vpdpbusd` and friends. EVEX-encoded VNNI raises #UD on CPUs that only have
    AVX-VNNI (Alder Lake, Arrow Lake, Lunar Lake, Zen4...). The binary compiles
    and links cleanly, then dies at runtime -- so verify the bytes, not the build.

Usage:
    python check_vnni_encoding.py build/vnni_demo.obj
    python check_vnni_encoding.py build/vnni_demo.exe --cpu avxvnni
    dumpbin /disasm x.obj > d.txt && python check_vnni_encoding.py --text d.txt

Exit codes:
    0  no problematic EVEX-encoded VNNI instructions for the target CPU
    1  found EVEX VNNI that will fault on the target CPU
    2  could not run dumpbin / bad input
"""

import argparse
import glob
import os
import re
import shutil
import subprocess
import sys

VNNI_MNEMONICS = {
    "vpdpbusd", "vpdpbusds", "vpdpbssd", "vpdpbssds",
    "vpdpbsud", "vpdpbsuds", "vpdpbuud", "vpdpbuuds",
    "vpdpwssd", "vpdpwssds",
}

# Intrinsics that MSVC 14.51 encodes as EVEX unless the _avx-suffixed form is used.
# Verified empirically: every 256-bit VNNI form HAS a legal VEX encoding
# (vpdpbssd -> C4 C2 77 50, vpdpbsud -> C4 C2 76 50, vpdpbuud -> C4 C2 74 50),
# so EVEX is never a hardware requirement here -- it is a codegen choice.
MSVC_EVEX_DEFAULT = {"vpdpbusd", "vpdpbusds"}

LINE = re.compile(
    r"^\s*([0-9A-Fa-f`]+):\s+([0-9A-Fa-f]{2}(?:\s[0-9A-Fa-f]{2})*)\s\s+(\S.*)$"
)
SKIP_TOKENS = {"vex", "evex", "vex2", "vex3", "rex", "rep"}


def find_dumpbin():
    exe = shutil.which("dumpbin") or shutil.which("dumpbin.exe")
    if exe:
        return exe
    patterns = [
        r"C:\Program Files\Microsoft Visual Studio\*\*\VC\Tools\MSVC\*\bin\Hostx64\x64\dumpbin.exe",
        r"C:\Program Files (x86)\Microsoft Visual Studio\*\*\VC\Tools\MSVC\*\bin\Hostx64\x64\dumpbin.exe",
    ]
    for p in patterns:
        hits = sorted(glob.glob(p))
        if hits:
            return hits[-1]
    return None


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()


def disasm(path, dumpbin):
    try:
        out = subprocess.run(
            [dumpbin, "/nologo", "/disasm", path],
            capture_output=True, text=True, encoding="utf-8", errors="replace",
        )
    except OSError as e:
        sys.stderr.write("error: failed to run dumpbin: %s\n" % e)
        sys.exit(2)
    return (out.stdout or "") + (out.stderr or "")


def scan(text):
    vex, evex = {}, {}
    for line in text.splitlines():
        m = LINE.match(line)
        if not m:
            continue
        addr, raw_bytes, rest = m.group(1), m.group(2), m.group(3)
        toks = rest.split()
        i = 0
        while i < len(toks) and toks[i].lower() in SKIP_TOKENS:
            i += 1
        if i >= len(toks):
            continue
        mnem = toks[i].lower()
        if mnem not in VNNI_MNEMONICS:
            continue
        first = int(raw_bytes.split()[0], 16)
        bucket = evex if first == 0x62 else vex
        bucket.setdefault(mnem, []).append((addr, raw_bytes.strip(), rest.strip()))
    return vex, evex


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", help=".obj / .exe / .dll to scan")
    ap.add_argument("--text", help="read an existing `dumpbin /disasm` output file instead")
    ap.add_argument("--cpu", default="avxvnni",
                    choices=["avxvnni", "avx512vnni"],
                    help="lowest target CPU: avxvnni = no AVX-512 (default)")
    ap.add_argument("-v", "--verbose", action="store_true",
                    help="list every offending instruction address")
    a = ap.parse_args()

    if a.text:
        text = read_text(a.text)
        source = a.text
    elif a.path:
        if not os.path.exists(a.path):
            sys.stderr.write("error: no such file: %s\n" % a.path)
            return 2
        dumpbin = find_dumpbin()
        if not dumpbin:
            sys.stderr.write(
                "error: dumpbin.exe not found. Open an 'x64 Native Tools Command "
                "Prompt for VS', or pass a pre-dumped file with --text.\n")
            return 2
        text = disasm(a.path, dumpbin)
        source = "%s (via %s)" % (a.path, dumpbin)
    else:
        ap.error("give a path or --text")

    vex, evex = scan(text)
    total = sum(len(v) for v in vex.values()) + sum(len(v) for v in evex.values())

    print("scanned: %s" % source)
    print("VNNI instructions found: %d\n" % total)

    for name, table in (("VEX  (C4/C5)", vex), ("EVEX (62)   ", evex)):
        if not table:
            continue
        for mnem in sorted(table):
            print("  %s  %-10s x%d" % (name, mnem, len(table[mnem])))

    evex_total = sum(len(v) for v in evex.values())
    print()

    if evex_total == 0:
        print("OK: all VNNI instructions are VEX-encoded - safe on AVX-VNNI CPUs.")
        return 0

    if a.cpu == "avx512vnni":
        print("OK: %d EVEX-encoded VNNI instruction(s); target has AVX512-VNNI so "
              "EVEX is legal." % evex_total)
        if a.verbose:
            for mnem, items in evex.items():
                for addr, raw, rest in items:
                    print("    %s: %-24s %s" % (addr, raw, rest))
        return 0

    print("PROBLEM: %d EVEX-encoded VNNI instruction(s) found." % evex_total)
    print("         Target CPU has AVX-VNNI but NOT AVX-512 -> these raise #UD.")
    print("   Every 256-bit VNNI form has a legal VEX encoding, so this is a")
    print("   codegen choice, not a hardware requirement. Fix:")
    for mnem in sorted(evex):
        # mnemonic "vpdpbusd" -> intrinsic base "dpbusd"
        base = mnem[2:] if mnem.startswith("vp") else mnem
        if mnem in MSVC_EVEX_DEFAULT:
            print("   * %s -> use _mm256_%s_avx_epi32() instead of _mm256_%s_epi32()"
                  % (mnem, base, base))
        else:
            print("   * %s -> MSVC emitted EVEX; hand-emit the VEX bytes." % mnem)
    print("     Generate them with scripts/vex_vnni_encode.py; see references/"
          "intrinsics-and-encoding.md for the full VEX/EVEX table.")
    if a.verbose:
        print()
        for mnem in sorted(evex):
            for addr, raw, rest in evex[mnem]:
                print("    %s: %-24s %s" % (addr, raw, rest))
    return 1


if __name__ == "__main__":
    sys.exit(main())
