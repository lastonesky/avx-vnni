---
name: avx-vnni
description: Write, debug and optimize INT8 x86 SIMD kernels with AVX-VNNI / AVX512-VNNI (vpdpbusd, vpdpbusds, vpdpwssd) using C intrinsics or hand-written MASM64 assembly. This skill should be used when a task involves int8/uint8 dot products, quantized GEMM / matmul, neural-network inference kernels, `_mm256_dpbusd_epi32` and related intrinsics, or when a VNNI binary dies with an illegal instruction (#UD) on Alder Lake / Arrow Lake / Zen4. Covers CPUID feature detection, the MSVC EVEX-vs-VEX encoding trap, hand-emitted VEX machine code for ml64, Windows x64 ABI volatile-register rules, and the data-layout the instruction requires.
agent_created: true
---

# AVX-VNNI

## Overview

VNNI (Vector Neural Network Instructions) collapses the INT8 "multiply-add-accumulate"
sequence into one instruction. `vpdpbusd` replaces `vpmaddubsw` + `vpmaddwd` + `vpaddd`
and removes the 16-bit intermediate saturation problem entirely.

This skill exists mainly because **getting VNNI to actually run is full of traps**
that a model will not know from first principles: MSVC silently emits the AVX-512
(EVEX) encoding, MASM64 refuses to emit the VEX encoding, and hand-written assembly
that touches YMM6–YMM15 corrupts the caller. Read the Pitfalls section before writing
any code.

## When to use

- Writing or reviewing an INT8/uint8 dot product, quantized GEMM, or inference kernel
- An existing `_mm256_dpbusd*` / `_mm512_dpbusd*` kernel crashes with `#UD`
- Porting an AVX2 INT8 kernel to VNNI and needing to know the speedup is worth it
- Writing hand-tuned MASM64/NASM assembly that uses `vpdpbusd`
- Asked "does this CPU support VNNI" or "why is my VNNI kernel slow"

## Quick reference

### Instruction semantics (256-bit, 8 int32 lanes)

```
for j in 0..7:                       # 8 int32 lanes
    tmp = 0
    for k in 0..3:                   # each lane eats 4 consecutive bytes
        tmp += (uint8)a[4*j+k] * (int8)b[4*j+k]
        #       ^^^^^^ UNSIGNED      ^^^^^ SIGNED  -- asymmetric, this is not a bug
    dst.d[j] = src.d[j] + tmp        # wrap (vpdpbusd) or signed-saturate (vpdpbusds)
```

Mnemonic decoder: `vpdp` + `B`/`W` (byte or word operands) + `U`/`S` (a-operand
signedness) + `U`/`S` (b-operand signedness) + `D`/`S` (accumulate: wrap or
signed-saturate). So `vpdp`+`b`+`u`+`s`+`d` = u8×s8 accumulate into i32 with wrap.

### CPUID detection

| Feature | Leaf | Bit | Meaning |
|---|---|---|---|
| AVX2 | `07H`, ECX=0 | EBX[5] | prerequisite |
| AVX512-VNNI | `07H`, ECX=0 | ECX[11] | EVEX forms |
| **AVX-VNNI** | `07H`, ECX=**1** | **EAX[4]** | VEX forms — the one people forget |
| AVX-VNNI_INT8 | `07H`, ECX=1 | EAX[4] | same bit |
| AVX-VNNI_INT16 | `07H`, ECX=1 | EAX[10] | `vpdpwssd` |

Also verify OS state with `XGETBV`: YMM needs `XCR0 & 0x6 == 0x6`, ZMM needs `XCR0 & 0xE6 == 0xE6`.

CPU support: AVX-VNNI on Intel Alder Lake+/Sapphire Rapids+, AMD Zen4+.
**Arrow Lake / Lunar Lake have AVX-VNNI but NO AVX-512.** Haswell→Rocket Lake have
neither. Always detect at runtime, never assume.

### Intrinsic selection

| Target | MSVC 14.51 (verified) | GCC / Clang |
|---|---|---|
| u8×s8 wrap | `_mm256_dpbusd_avx_epi32` → VEX | `_mm256_dpbusd_epi32` (`-mavxvnni`) |
| u8×s8 saturate | `_mm256_dpbusds_avx_epi32` → VEX | `_mm256_dpbusds_epi32` |
| u8×s8 wrap, **no suffix** | `_mm256_dpbusd_epi32` → **EVEX** ✗ | n/a |
| s8×s8 wrap | `_mm256_dpbssd_epi32` → VEX (safe) | `_mm256_dpbssd_epi32` (`-mavx512vnni`; encoding not verified here) |
| i16×i16 | `_mm256_dpwssd_avx_epi32` → VEX | `_mm256_dpwssd_avx_epi32` |
| 512-bit | `_mm512_dpbusd_epi32` → EVEX (needs AVX-512) | same, `-mavx512vnni` |

Portable wrapper to use in every project:

```c
#if defined(_MSC_VER)
#  define DPBUSD_256(c,a,b)  _mm256_dpbusd_avx_epi32 ((c),(a),(b))
#  define DPBUSDS_256(c,a,b) _mm256_dpbusds_avx_epi32((c),(a),(b))
#else
#  define DPBUSD_256(c,a,b)  _mm256_dpbusd_epi32     ((c),(a),(b))
#  define DPBUSDS_256(c,a,b) _mm256_dpbusds_epi32    ((c),(a),(b))
#endif
```

**Correction to a common belief:** `vpdpbssd` (s8×s8) is *not* AVX512-only.
Verified on an AVX-512-less Arrow Lake: `_mm256_dpbssd_epi32` compiles to
`C4 C2 77 50 00` (VEX) and executes correctly (`0xFE × 1 × 4 = -8`, versus
`+1016` for `vpdpbusd`). All four byte-product variants live at opcode `50`/`51`
in the `0F38` map and differ only in the VEX `pp` field:

| pp | a × b | mnemonic |
|---|---|---|
| `00` | u8 × u8 | `vpdpbuud` |
| `01` | u8 × s8 | `vpdpbusd` |
| `10` | s8 × u8 | `vpdpbsud` |
| `11` | s8 × s8 | `vpdpbssd` |

The four i8 forms are all reachable as VEX; only the u8×s8 intrinsics *without*
the `_avx` suffix flip to EVEX in MSVC.

## Workflow

### 1. Detect, do not assume

Run CPUID leaf 7 subleaf 0 **and** 1, plus XGETBV. Copy `assets/vnni_demo.c`'s
`detect_cpu()` — it is verified working.

### 2. Choose the encoding path (this decides crash vs run)

- Pure C intrinsics on MSVC → for u8×s8 use the `_avx`-suffixed intrinsic.
  Plain `_mm256_dpbusd_epi32` compiles fine and then **crashes at runtime**
  (process exit 132, SIGILL).
- Hand-written MASM64 → `ml64` emits EVEX for `vpdpbusd` and rejects `{vex3}`.
  Hand-emit VEX bytes with `db`; generate them with `scripts/vex_vnni_encode.py`.
- Do not infer the encoding from the intrinsic name — two of twelve intrinsics
  differ from the rest. Verify with `scripts/check_vnni_encoding.py`.

### 3. Write the kernel

- Unroll to **4 accumulators** minimum (vpdpbusd latency ≈ 5 cycles, throughput 2/cycle).
- Feed it 128 bytes per loop iteration (4 × 32-byte vectors).
- Keep the tail handling: a 32-byte block loop, then a scalar tail.
- Match the layout: each lane consumes 4 **consecutive** K. For GEMM that means
  `B` stored as `B[n*K + k]` (n-major, k contiguous), not the usual k-major.

Copy the verified kernels from `assets/vnni_demo.c` (`dot_vnni`, `gemm_vnni`) and
`assets/vnni_asm.asm` rather than writing from scratch.

### 4. Verify the encoding before shipping

```
python scripts/check_vnni_encoding.py <file.obj|file.exe> --cpu avxvnni
```

Any EVEX-encoded VNNI instruction found on an AVX-VNNI-only target is a guaranteed `#UD`.

### 5. Validate correctness and measure

- Compare against a scalar reference with **large-magnitude** data, not just small.
- Expect ~2× over a pure-AVX2 `vpmaddubsw` emulation and ~6-7× over scalar.
- Ceiling is the **load port**, not the ALU: 2 × 32-byte loads/cycle. Roughly
  350 GB/s and 175 GMAC/s on a 5 GHz core. Do not chase more unrolling past that.

## Pitfalls — check every one

1. **MSVC emits EVEX for the two unsuffixed u8×s8 intrinsics.**
   `_mm256_dpbusd_epi32` / `_mm256_dpbusds_epi32` → `62 …` (AVX512-VNNI).
   On Arrow Lake this is an immediate `#UD` — observed as process exit code 132.
   Use `_mm256_dpbusd_avx_epi32` / `_mm256_dpbusds_avx_epi32` → `C4 …`.
   The other ten VNNI intrinsics already emit VEX.

2. **ml64 also emits EVEX**, and `{vex3}` / `{vex2}` qualifiers are unsupported
   (A2008 / A2009 in both prefix and suffix position). Hand-emit VEX bytes.

3. **Windows x64 ABI: YMM6–YMM15 are non-volatile.** Hand-written asm that uses
   `ymm6`/`ymm7` without saving them silently corrupts the caller. Observed symptom:
   a benchmark timing variable became `3.7e-289`, 100 % reproducible, extremely hard
   to trace. Restrict hand-written asm to YMM0–YMM5 (reuse two as temporaries), or
   save/restore on the stack.

4. **Data layout.** vpdpbusd's 8 lanes each eat 4 consecutive bytes. A k-major `B`
   forces extra shuffles and kills the gains.

5. **Pure-AVX2 emulation is not just slower, it is wrong for large values.**
   `vpmaddubsw` saturates at int16: `255*127*2 = 64770` clamps to `32767`, so
   `255*127*4` yields `65534` instead of `129540`. This is the strongest argument
   for VNNI beyond raw throughput.

6. **MSVC and non-ASCII sources.** Compile UTF-8 C files with `/utf-8` (or add a BOM);
   otherwise bytes are silently dropped (`测` → `?`, warning C4819).

7. **Horizontal sum costs.** Accumulate in 4 × `__m256i` and reduce once at the end.
   Do not reduce inside the loop.

## Resources

### scripts/

- `vex_vnni_encode.py` — compute the exact VEX.256 bytes for all ten VNNI
  instructions (`vpdpbuud(s)`, `vpdpbusd(s)`, `vpdpbsud(s)`, `vpdpbssd(s)`,
  `vpdpwssd(s)`) given (dst, vvvv, base, disp). Every entry reproduces MSVC/
  `dumpbin` output byte-for-byte. Use this instead of hand-deriving VEX prefixes.
- `check_vnni_encoding.py` — disassemble a `.obj`/`.exe` with `dumpbin` and report
  EVEX vs VEX VNNI instructions. Run before shipping; catches pitfall 1 and 2.

### references/

- `intrinsics-and-encoding.md` — full intrinsic tables per compiler, CPUID details,
  CPU support matrix, VEX prefix bit-field layout, worked encodings.
- `kernel-patterns.md` — dot product / GEMM / horizontal-reduction patterns, data
  layout rules, accumulator-count and roofline reasoning.
- `msvc-toolchain.md` — locating `cl.exe`/`ml64.exe`, setting INCLUDE/LIB/PATH without
  `cmd.exe`, `/utf-8`, `dumpbin` verification, Windows x64 ABI register volatility.

### assets/

- `vnni_demo.c` — complete verified demo: CPUID detection, semantics walkthrough,
  4-way-accumulator dot product, quantized GEMM, scalar cross-check, benchmarking.
- `vnni_asm.asm` — verified MASM64 dot product with hand-emitted VEX encoding.
- `build_msvc.bat` — one-command `cl` + `ml64` + `link` build.
- `sample_output.txt` — expected output on an AVX-VNNI / no-AVX-512 CPU.
