# MSVC / MASM64 toolchain notes

Verified on this machine (Visual Studio 18 Enterprise, MSVC 14.51.36231,
Windows SDK 10.0.26100.0).

## 1. Locating the tools

```
cl.exe       C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231\bin\Hostx64\x64\cl.exe
ml64.exe     ...\bin\Hostx64\x64\ml64.exe
dumpbin.exe  ...\bin\Hostx64\x64\dumpbin.exe
link.exe     ...\bin\Hostx64\x64\link.exe
vcvarsall    C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Auxiliary\Build\vcvarsall.bat
SDK          C:\Program Files (x86)\Windows Kits\10\{Include,Lib}\10.0.26100.0
```

Glob `**\VC\Tools\MSVC\*\bin\Hostx64\x64\*.exe` rather than hard-coding the
version — `14.51.36231` will change after an update.

## 2. Building without `cmd.exe`

`vcvarsall.bat` needs `cmd.exe`, and both the Bash and PowerShell tool wrappers
here reject `cmd.exe`. Set the environment directly instead:

```powershell
$msvc = "C:\Program Files\Microsoft Visual Studio\18\Enterprise\VC\Tools\MSVC\14.51.36231"
$sdk  = "C:\Program Files (x86)\Windows Kits\10"
$sdkv = "10.0.26100.0"
$env:INCLUDE = "$msvc\include;$sdk\Include\$sdkv\ucrt;$sdk\Include\$sdkv\um;$sdk\Include\$sdkv\shared;$sdk\Include\$sdkv\winrt;"
$env:LIB     = "$msvc\lib\x64;$sdk\Lib\$sdkv\ucrt\x64;$sdk\Lib\$sdkv\um\x64;"
$env:PATH    = "$msvc\bin\Hostx64\x64;$env:PATH"

cl    /nologo /O2 /arch:AVX2 /utf-8 /std:c17 /EHsc /W3 /c vnni_demo.c
ml64  /nologo /c /Cx /W3 vnni_asm.asm
link  /nologo /subsystem:console /machine:x64 vnni_demo.obj vnni_asm.obj /out:vnni_demo.exe
```

For interactive user builds, prefer `assets/build_msvc.bat` — it calls
`vcvarsall.bat` and works from a normal shell or by double-clicking.

### Capture gotchas

- **PowerShell's stdout is frequently dropped.** Redirect to a file
  (`*>&1 | Out-File -Encoding utf8 x.log`) and read it back.
- **PowerShell redirects write UTF-16.** Reading those logs as UTF-8 yields
  mojibake. Running the `.exe` from Bash gives clean UTF-8.
- `/utf-8` (or a UTF-8 BOM) is mandatory for non-ASCII sources. Without it MSVC
  reads the file as the ANSI codepage and silently drops bytes — e.g. `测`
  becomes `?` with only warning C4819 to show for it.

## 3. Useful flags

| Flag | Purpose |
|---|---|
| `/O2` | required; intrinsics still work without it but codegen is bad |
| `/arch:AVX2` | not required for intrinsics, but avoids AVX/SSE transition penalties elsewhere |
| `/utf-8` | correct handling of non-ASCII string literals |
| `/c` | compile only, so the `.obj` can be linked with `ml64` output |
| `/Fa` | emit an `.asm` listing — handy to eyeball generated VNNI encodings |
| `dumpbin /disasm` | the authoritative check on VEX vs EVEX |

## 4. Windows x64 ABI — register volatility

| Volatile (free to clobber) | Non-volatile (must preserve) |
|---|---|
| RAX, RCX, RDX, R8, R9, R10, R11 | RBX, RBP, RDI, RSI, R12–R15 |
| **YMM0–YMM5** | **YMM6–YMM15** |
| XMM0–XMM5, flags | XMM6–XMM15 |

**This is the single most expensive bug in hand-written VNNI assembly.** Using
`ymm6`/`ymm7` as scratch without saving them corrupts the caller. Because the
caller is often compiled with `/O2` and keeps live values in XMM6–XMM15, the
symptom is silent data corruption far from the cause. Observed here: a
benchmark's `best` variable became `3.7e-289`, 100 % reproducible, with no crash
and no warning.

Mitigations, in order of preference:
1. Restrict hand-written asm to **YMM0–YMM5**. Four accumulators (`ymm0`–`ymm3`)
   plus two reused temporaries (`ymm4`, `ymm5`) is enough — see
   `assets/vnni_asm.asm`.
2. If more vector registers are needed, save them on the stack:
   `sub rsp, 64` → `vmovdqu [rsp], ymm6` → restore before `ret`.

Also: finish with `vzeroupper` before `ret` to avoid the AVX↔SSE transition
penalty in the caller.

## 5. Verifying the build

```
dumpbin /disasm vnni_demo.obj | findstr vpdpbusd
python scripts\check_vnni_encoding.py vnni_demo.exe --cpu avxvnni
```

Expect `C4 …` (VEX) lines. Any `62 …` (EVEX) line on an AVX-VNNI-only target is
a guaranteed #UD at runtime.
