# AVX-VNNI intrinsics and encoding reference

Everything in the "verified" tables below was measured on this machine with
MSVC 14.51 (`cl /O2 /arch:AVX2`) + `dumpbin /disasm`, on an Intel Arrow Lake
CPU that has AVX-VNNI but no AVX-512. Items marked *(inferred)* are from the
ISA definition and were not executed here.

## 1. Instruction semantics

```
VEX.256 vpdpbusd  dst, src1(vvvv), src2(r/m)          # u8 x s8 -> i32, wrap
VEX.256 vpdpbusds dst, src1(vvvv), src2(r/m)          # u8 x s8 -> i32, signed-saturate
VEX.256 vpdpbssd  dst, src1(vvvv), src2(r/m)          # s8 x s8 -> i32, wrap
VEX.256 vpdpbssds dst, src1(vvvv), src2(r/m)          # s8 x s8 -> i32, saturate
VEX.256 vpdpbsud / vpdpbuud                           # s8 x u8 / u8 x u8
VEX.256 vpdpwssd / vpdpwssds                          # i16 x i16 -> i32
```

```
for j in 0..7:                        # 8 int32 lanes (256-bit)
    tmp = 0
    for k in 0..3:                    # each lane eats 4 CONSECUTIVE bytes
        tmp += a[4*j+k] * b[4*j+k]    # signedness per the mnemonic
    dst.d[j] = src.d[j] + tmp         # 50 -> wrap, 51 -> signed saturate
```

Naming decoder: `PDP` `B` `<a-signedness>` `S` `<D|S>`
- 3rd letter group `U|S` = a-operand signedness, next `S` = b-operand is signed
- final `D` = wrap (Dst +=), `S` = saturate

**The a-operand is unsigned in `vpdpbusd`.** This matches asymmetric quantization
(non-negative activations × signed weights) and is not a bug.

## 2. CPUID

| Feature | Leaf / subleaf | Register bit |
|---|---|---|
| AVX2 (prerequisite) | `07H`, ECX=0 | EBX[5] |
| AVX512F | `07H`, ECX=0 | EBX[16] |
| AVX512-VNNI | `07H`, ECX=0 | ECX[11] |
| **AVX-VNNI** (INT8) | `07H`, ECX=**1** | **EAX[4]** |
| AVX-VNNI_INT16 | `07H`, ECX=1 | EAX[10] |
| BF16 (`vpdpbf16ps`) | `07H`, ECX=1 | EAX[5] |

OS state must also be checked with `XGETBV`:
- YMM usable: `(xcr0 & 0x6) == 0x6` (SSE + AVX state)
- ZMM usable: `(xcr0 & 0xE6) == 0xE6` (+ opmask, ZMM_Hi256, Hi16_ZMM)

Verifying `CPUID.7.1:EAX[4]` is the step people skip, then report "no VNNI"
on CPUs that do have it.

### CPU support (rough)

| CPU | AVX-VNNI | AVX-512 |
|---|---|---|
| Haswell → Rocket Lake | no | no (except some SKX/ICX server parts) |
| Alder Lake (12th–14th gen) | yes | no (AVX-512 fused off) |
| **Arrow Lake / Lunar Lake** | **yes** | **no** |
| Sapphire Rapids+ | yes | yes (AVX512-VNNI) |
| AMD Zen 4 / Zen 5 | yes | no (Zen 4 has AVX-512 with 256-bit datapath, but no AVX512-VNNI) |

## 3. Verified MSVC 14.51 encoding table

Compiled `noinline` wrappers around each intrinsic with `/O2 /arch:AVX2`,
then disassembled. All forms use VEX unless noted.

| Intrinsic | Bytes | Encoding |
|---|---|---|
| `_mm256_dpbusd_epi32` | `62 D2 75 28 50 00` | **EVEX** ← the trap |
| `_mm256_dpbusd_avx_epi32` | `C4 C2 75 50 00` | VEX.256 0F38 pp=66 op=50 |
| `_mm256_dpbusds_epi32` | `62 D2 75 28 51 00` | **EVEX** ← the trap |
| `_mm256_dpbusds_avx_epi32` | `C4 C2 75 51 00` | VEX.256 0F38 pp=66 op=51 |
| `_mm256_dpbssd_epi32` | `C4 C2 77 50 00` | VEX.256 0F38 pp=F2 op=50 |
| `_mm256_dpbssds_epi32` | `C4 C2 77 51 00` | VEX.256 0F38 pp=F2 op=51 |
| `_mm256_dpbsud_epi32` | `C4 C2 76 50 00` | VEX.256 0F38 pp=F3 op=50 |
| `_mm256_dpbsuds_epi32` | `C4 C2 76 51 00` | VEX.256 0F38 pp=F3 op=51 |
| `_mm256_dpbuud_epi32` | `C4 C2 74 50 00` | VEX.256 0F38 pp=none op=50 |
| `_mm256_dpbuuds_epi32` | `C4 C2 74 51 00` | VEX.256 0F38 pp=none op=51 |
| `_mm256_dpwssd_avx_epi32` | `C4 C2 75 52 00` | VEX.256 0F38 pp=66 op=52 |
| `_mm256_dpwssds_avx_epi32` | `C4 C2 75 53 00` | VEX.256 0F38 pp=66 op=53 |

### Key conclusions

1. **Only `vpdpbusd` / `vpdpbusds` flip to EVEX by default.** Everything else
   already emits VEX. So the practical rule is narrower than "MSVC emits EVEX
   for VNNI": it is the two u8×s8 intrinsics *without* the `_avx` suffix.
2. **`vpdpbssd` (s8×s8) is NOT AVX512-only.** Verified: it emits
   `C4 C2 77 50` (VEX) and executes correctly on an AVX-512-less Arrow Lake
   (`0xFE × 1` → `-8`, vs `+1016` for `vpdpbusd`). Do not gate it behind an
   AVX-512 check.
3. **The four byte-product variants share opcode `50` and are distinguished only
   by the VEX `pp` field** (implied legacy prefix):

   | pp | prefix | a × b |
   |---|---|---|
   | `00` | none | u8 × u8 (`vpdpbuud`) |
   | `01` | 66 | u8 × s8 (`vpdpbusd`) |
   | `10` | F3 | s8 × u8 (`vpdpbsud`) |
   | `11` | F2 | s8 × s8 (`vpdpbssd`) |

   opcode `51` = the saturating twin of each.

4. **The encoding is not predictable from the intrinsic name.** Always confirm
   with `scripts/check_vnni_encoding.py`.

## 4. VEX / EVEX prefix bit layout

3-byte VEX (used whenever X̄/B̄/W or a non-default mmmmm is needed):

```
byte1  C4
byte2  [7]~R  [6]~X  [5]~B  [4:0] mmmmm
                                   00001 = 0F, 00010 = 0F38, 00011 = 0F3A
byte3  [7]W  [6:3]~vvvv  [2]L  [1:0]pp
                                 L=0/1 = 128/256-bit
                                 pp: 00 none, 01 = 66, 10 = F3, 11 = F2
then: opcode [, modrm [, sib] [, disp] ]
```

`R`/`X`/`B` are the high bits of `modrm.reg`, `sib.index`, `modrm.rm`/`sib.base`
(same extension role as REX.R/X/B, inverted). `vvvv` is the first source
operand and **must be a register** — `vpdpbusd` takes `src2` from memory but
never `src1`.

EVEX:

```
byte1  62
byte2  [7]~R [6]~X [5]~B [4]~R' [3:0] mmm  (mm mmm = 000 0F, 001 0F38, 010 0F3A)
byte3  [7]W [6:3]~vvvv [2]1 [1:0]pp
byte4  [7]z [6:4]L'L [3]b [2]~V' [1:0]aaa
```

Worked decode of `C4 E2 5D 50 02` (`vpdpbusd ymm0, ymm4, [rdx]`):

```
C4           3-byte VEX
E2 = 1110 0010   ~R=1(R=0 -> ymm0) ~X=1 ~B=1(B=0 -> rdx) mmmmm=00010 (0F38)
5D = 0101 1101   W=0  ~vvvv=1011 (vvvv=0100 -> ymm4)  L=1 (256-bit)  pp=01 (0F38)
50            opcode
02 = 00 000 010  mod=00 reg=000 (ymm0) rm=010 (rdx)
```

## 5. GCC / Clang

- No `_avx` suffix exists; `-mavxvnni` makes `_mm256_dpbusd_epi32` emit VEX.
- Without `-mavxvnni` (only `-mavx2`) the intrinsic is unavailable.
- `-mavx512vnni` unlocks `vpdpbssd` / `vpdpbsud` / `vpdpbuud` (EVEX forms).
- Portable wrapper lives in SKILL.md.

## 6. MASM64 / ml64

- `vpdpbusd` mnemonic assembles to the **EVEX** encoding by default.
- `{vex3}` / `{vex2}` encoding qualifiers are **rejected** (A2008 in prefix
  position, A2009 in suffix position). Do not waste time on them.
- Emit raw bytes: `db 0C4h, 0E2h, 05Dh, 050h, 002h`.
- Generate them with `scripts/vex_vnni_encode.py`; it reproduces every byte in
  the tables above exactly.

NASM note *(inferred)*: NASM does support `{vex3}` for some instructions via
`vpdpbusd ymm0, ymm4, [rdx]` + `%use` — verify with a disassembly before relying
on it; raw `db` always works.
