# VNNI kernel patterns

Measured on Intel Core Ultra 7 270K Plus (Arrow Lake), MSVC 14.51 `/O2 /arch:AVX2`.
Working code: `assets/vnni_demo.c` and `assets/vnni_asm.asm`.

## 1. Data layout is the first decision

`vpdpbusd` lane *j* consumes `a[4j+k]`, `k = 0..3`. So each lane needs **4
consecutive elements of K**. Consequences:

- **Dot product** — trivially satisfied: stream both operands contiguously.
- **GEMM** `C[M][N] = A[M][K] × B[K][N]` — store `B` as `B[n*K + k]`
  (n-major, k contiguous). With the textbook k-major `B[k*N + n]`, every lane
  would need 4 `n` values, forcing shuffles and giving back most of the win.
- **Requantization / accumulation** — keep the i32 accumulator vector across the
  whole K loop; only horizontally reduce at the very end.

## 2. Dot product (4 accumulators, 128 bytes/iteration)

```c
static int32_t dot_vnni(const uint8_t *a, const int8_t *b, size_t n) {
    __m256i a0 = _mm256_setzero_si256(), a1 = a0, a2 = a0, a3 = a0;
    size_t i = 0;
    for (; i + 128 <= n; i += 128) {
        a0 = DPBUSD_256(a0, LD(a + i     ), LD(b + i     ));
        a1 = DPBUSD_256(a1, LD(a + i + 32), LD(b + i + 32));
        a2 = DPBUSD_256(a2, LD(a + i + 64), LD(b + i + 64));
        a3 = DPBUSD_256(a3, LD(a + i + 96), LD(b + i + 96));
    }
    for (; i + 32 <= n; i += 32) a0 = DPBUSD_256(a0, LD(a + i), LD(b + i));
    int32_t s = hsum_epi32(_mm256_add_epi32(_mm256_add_epi32(a0, a1),
                                            _mm256_add_epi32(a2, a3)));
    for (; i < n; ++i) s += (int32_t)a[i] * (int32_t)b[i];   /* scalar tail */
    return s;
}
```

`LD(p)` = `_mm256_loadu_si256((const __m256i *)(p))`.

Three-part structure is mandatory: 128-byte main loop → 32-byte loop → scalar
tail. Forgetting the scalar tail produces wrong results for `n % 32 != 0`.

## 3. Horizontal sum (once, at the end)

```c
static inline int32_t hsum_epi32(__m256i v) {
    __m128i s = _mm_add_epi32(_mm256_castsi256_si128(v),
                              _mm256_extracti128_si256(v, 1));
    s = _mm_add_epi32(s, _mm_shuffle_epi32(s, 0x4E));  /* swap 64-bit halves */
    s = _mm_add_epi32(s, _mm_shuffle_epi32(s, 0xB1));  /* swap 32-bit halves */
    return _mm_cvtsi128_si32(s);
}
```

Never call this inside the loop.

## 4. Why 4 accumulators

`vpdpbusd` latency ≈ 5 cycles, throughput ≈ 2/cycle. A single accumulator chain
issues 1 op per 5 cycles (0.2/cycle). Four independent chains already cover the
observed practical limit; more registers give diminishing returns because the
kernel becomes load-bound (see §6).

## 5. Why VNNI is not merely "faster"

The AVX2 emulation path is **numerically wrong** for large values:

```
vpmaddubsw: 255*127 + 255*127 = 64770  -> saturates to int16 max 32767
vpmaddwd:   32767 + 32767              = 65534        <-- wrong
vpdpbusd:   255*127 * 4                = 129540       <-- correct
```

`vpmaddubsw` clamps at int16; `vpdpbusd` accumulates straight into int32 with no
intermediate. This is the strongest correctness argument for VNNI, and a good
test case: cross-check a kernel with `a = 255, b = 127` saturating data, not
only with small random values.

## 6. Expected performance

Measured, 16 KiB dot product × 20000 iterations (data in L1/L2):

| Kernel | ms | GMAC/s | GB/s |
|---|---|---|---|
| scalar | 12.6 | 26 | 52 |
| AVX2 emulation (`vpmaddubsw`+`vpmaddwd`) | 3.7 | 88 | 175 |
| AVX-VNNI (C intrinsics, 4 accumulators) | 1.86 | 176 | 352 |
| AVX-VNNI (hand-written MASM64) | 1.87 | 175 | 351 |

GEMM 96×96×256, all elements verified against scalar: 0.015 ms/call, ~320 GMAC/s.

**Roofline:** 176 GMAC/s × 2 bytes/MAC ≈ 352 GB/s ≈ 64 bytes/cycle at ~5.5 GHz.
That is exactly 2 × 32-byte loads per cycle, i.e. the **load port limit**, not
the VNNI ALU limit. Do not expect more unrolling or more accumulators to help
once this wall is hit — to go faster, reduce bytes loaded (better blocking /
cache reuse), not instructions.

## 7. Validation checklist

1. Compare against a scalar reference, elementwise, for the full output.
2. Test with **extreme** values (0x00/0xFF, ±127) to catch saturation bugs.
3. Test with `n` not a multiple of 32 *and* 128 (tail paths).
4. Run `scripts/check_vnni_encoding.py` on the built object.
5. Time with the best-of-N over ≥3 runs; discard the first (warm-up).
6. Use a `volatile` sink for the result so the loop is not optimized away.
